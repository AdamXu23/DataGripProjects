ALTER TABLE Port_Table ALTER COLUMN EQ varchar(20);
ALTER TABLE Port_Table ALTER COLUMN Name varchar(20);