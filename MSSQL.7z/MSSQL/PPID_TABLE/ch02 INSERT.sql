insert into PPID_Table values ('PPID10',600,600,350,80);
insert into PPID_Table values ('PPID20',300,300,350,80);
insert into PPID_Table values ('PPID30',300,0,350,80);