insert into Foup_Log_List
    (Id,EQ,Name,IP,Port,O2_Enable,RH_Enable,Port_Enable,FOUP_ID,Arrive_Time)values
(1,'SOHC000','001','192.168.127.001',950,1,1,1,'AVEX0001',convert(datetime, '2021-11-30 10:34:09', 120)),
(2,'SOHC000','002','192.168.127.002',950,1,1,1,'AVEX0002',convert(datetime, '2021-11-29 10:34:09', 120)),
(3,'SOHC000','003','192.168.127.003',950,1,1,1,'AVEX0003',convert(datetime, '2021-11-28 10:34:09', 120)),
(4,'SOHC000','004','192.168.127.004',950,1,1,1,'AVEX0004',convert(datetime, '2021-11-27 10:34:09', 120)),
(5,'SOHC000','005','192.168.127.005',950,1,1,1,'AVEX0005',convert(datetime, '2021-11-26 10:34:09', 120)),
(6,'SOHC000','006','192.168.127.006',950,1,1,1,'AVEX0006',convert(datetime, '2021-11-25 10:34:09', 120));