UPDATE Foup_Log_List SET
                         Recipe_ID = 'PPID20',
                         Recipe_T1 =  300,
                         Recipe_T2 =  300,
                         Recipe_F1 =  350,
                         Recipe_F2 =  80
                         WHERE FOUP_ID = 'AVEX0001' AND Arrive_Time = '2021-11-30 10:34:09.000' ;