insert into Login_Table values ('Administrator','AVEX1234',0);
insert into Login_Table values ('ADMIN','SOHC',1);

-- select * from Login_Table where User_Name = 'ADMIN' collate Chinese_PRC_CS_AI;
select * from Login_Table;