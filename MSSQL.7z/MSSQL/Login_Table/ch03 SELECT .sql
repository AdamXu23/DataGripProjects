select * from Login_Table where User_Name = 'ADMIN' collate Chinese_PRC_CS_AI;
select * from Login_Table;